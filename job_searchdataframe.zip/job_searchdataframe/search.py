'''
Created on 3/12/2019
Author: Taiwo O. Adetiloye
Email: taiwo.adetiloye@gmail.com
Website: taiwotman.github.io
'''


from pyspark.sql.types import *
from .base import Algorithm
from .spark import get_spark
import datetime


class SearchCol1ValuesInRestCols(Algorithm):

    def do_sparkjob(self):

        start_time = datetime.datetime.now()
        print("\n\t Start date-time: " + start_time.strftime("%Y-%m-%d %H:%M:%S") + "\n")

        # get spark session
        spark = get_spark()

        # create structfield using array list
        cSchema = StructType([StructField("id", StringType()),
                              StructField("col1", IntegerType()),
                              StructField("col2", IntegerType()),
                              StructField("col3", IntegerType()),
                              StructField("col4", IntegerType())])

        test_data = [['as1', 4, 10, 4, 6],
                     ['as2', 6, 3, 6, 1],
                     ['as3', 6, 0, 2, 1],
                     ['as4', 8, 8, 6, 1],
                     ['as5', 9, 6, 6, 9]]

        # create pyspark dataframe
        df = spark.createDataFrame(test_data, schema=cSchema)

        df.show()

        # obtain the distinct items for col 1
        distinct_list = [i.col1 for i in df.select("col1").distinct().collect()]
        col_list = ['id', 'col2', 'col3', 'col4']

        # implement the search of values in rest column that in col 1
        def search(distinct_list ):
            for i in distinct_list :
                print(str(i) + ' found in: ')

                # for col in df.columns:
                for col in col_list:
                    df_search = df.select(*col_list) \
                        .filter(df[str(col)] == str(i))

                    if (len(df_search.head(1)) > 0):
                        df_search.show()

        search(distinct_list)

    def do_endjob(self):
        end_time = datetime.datetime.now()
        print("\n\t End date-time: " + end_time.strftime("%Y-%m-%d %H:%M:%S") + "\n")
