'''
Created on 3/12/2019
Author: Taiwo O. Adetiloye
Email: taiwo.adetiloye@gmail.com
Website: taiwotman.github.io
'''

import sys
import abc


class Algorithm(object):
    __metaclass__ = abc.ABCMeta

    def template_method(self):
        """Skeleton of operations to perform. DON'T override me.

        The Template Method defines a skeleton of an algorithm in an operation,
        and defers some steps to subclasses.
        """

        self.__desc_algorithm()
        self.do_sparkjob()
        self.do_endjob()

    # def __init__(self, default):
    #     self.default = default

    def __desc_algorithm(self):
        """Protected operation. DON'T override me."""
        print(" Search the rest columns of pyspark dataframe for values in column1 \n")
        this_method_name = sys._getframe().f_code.co_name
        print('{}.{}\n'.format(self.__class__.__name__, this_method_name))


    @abc.abstractmethod
    def do_sparkjob(self):
        """Primitive operation. You HAVE TO override me, I'm a placeholder."""
        pass

    def do_endjob(self):
        """Hook. You CAN override me, I'm NOT a placeholder."""
        pass

