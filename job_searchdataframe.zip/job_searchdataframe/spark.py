'''
Created on 3/12/2019
Author: Taiwo O. Adetiloye
Email: taiwo.adetiloye@gmail.com
Website: taiwotman.github.io
'''



from pyspark.sql import SparkSession


def get_spark():
    spark = SparkSession \
        .builder \
        .appName("Python Spark SQL basic example") \
        .getOrCreate()

    return spark

